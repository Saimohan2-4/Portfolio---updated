import Typography from "../components/general/typography"

const TestimonialsSection = () => {
    return (
        <div>
            <Typography variant="body1">
                Testimonials
            </Typography>
        </div>
    )
}

export default TestimonialsSection